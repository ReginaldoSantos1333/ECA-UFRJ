# Fuzzy-Algorithm-Demonstration
A project using SKfuzzy library to predict which emotion someone can be feeling, simplificated. 
